function execute(url) {
    var res = fetch(url);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    
    var name = doc.select("h1.novel-title").text().trim();
    var cover = doc.select("figure.cover img").first().attr("data-src") || doc.select("figure.cover img").first().attr("src");
    if (cover && cover.indexOf("http") !== 0) cover = "https://novelfire.net" + (cover.indexOf("/") === 0 ? "" : "/") + cover;
    
    var author = doc.select(".author span[itemprop='author'], .author a").first().text().trim();
    var statsEl = doc.select(".header-stats strong");
    
    var chapters = statsEl.get(0) ? statsEl.get(0).text().trim() : "N/A";
    chapters = chapters.replace(/^\d+[\s.\-:]*(Chapter|Chương)/i, "$1").replace(/(Chapter\s*\d+[\s:.-]*)(?:Chapter\s*\d+[\s:.-]*)+/gi, "$1");
    
    var views = statsEl.get(1) ? statsEl.get(1).text().trim() : "N/A";
    var status = statsEl.get(3) ? statsEl.get(3).text().trim() : (statsEl.get(2) ? statsEl.get(2).text().trim() : "Ongoing");
    var rank = doc.select(".rating .score, .rating strong, span[itemprop='ratingValue']").first().text().trim();
    
    var cats = [];
    doc.select(".categories ul li a").forEach(function(e) { cats.push(e.text().trim()); });
    var catStr = cats.slice(0, 5).join(", ") + (cats.length > 5 ? " ...." : "");
    
    // Khởi tạo Tags Link
    var tagLinks = [];
    var tagNodes = doc.select(".tags ul li a, .tags a, a[href*='/tag/']");
    tagNodes.forEach(function(e) { 
        var link = e.attr("href");
        if (link.indexOf("http") !== 0) link = "https://novelfire.net" + (link.indexOf("/") === 0 ? "" : "/") + link;
        tagLinks.push('<a href="' + link + '">' + e.text().trim() + '</a>'); 
    });
    
    var info = [
        "👤 Tác giả: " + author,
        "📖 Số chương: " + chapters,
        "👁️ Lượt xem: " + views,
        "👑 Ranking: " + (rank || "N/A"),
        "📌 Trạng thái: " + status,
        "🎭 Thể loại: " + catStr
    ];
    
    // Xử lý tóm tắt & chèn Tags vào cuối
    var summary = doc.select("div.summary .content");
    if (!summary.html()) summary = doc.select(".summary .expand-wrapper");
    summary.select(".expand-btn, a.btn-more, a[data-toggle='expand']").remove();
    
    var descHtml = summary.html() ? summary.html().replace(/Show more/gi, "").trim() : "";
    if (tagLinks.length > 0) {
        descHtml += "<br><br><b>🏷️ Tags:</b> " + tagLinks.join(", ");
    }
    
    return Response.success({
        name: name, cover: cover, author: author,
        description: descHtml,
        detail: info.join("<br>"),
        host: "https://novelfire.net"
    });
}