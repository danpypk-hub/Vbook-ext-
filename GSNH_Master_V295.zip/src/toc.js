load("config.js");
function clean(t) {
    let s = t.trim();
    s = s.replace(/\s*\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}.*/g, ""); 
    s = s.replace(/(?:#|ttty|gsnh|ttyy)[\s\-]*\d+[\s\-–]*/gi, "");   
    return s.replace(/^[^a-zA-Z0-9À-ỹ]+/, "").trim() || "Chương";
}
function execute(url) {
    let res = fetch(url);
    if (res.ok) {
        let chapters = [];
        res.html().select(".chapter-list a, .es-story-link").forEach(e => {
            let href = e.attr("href");
            if (href) {
                if (href.indexOf("http") !== 0) href = BASE_URL + (href.indexOf("/") === 0 ? "" : "/") + href;
                chapters.push({
                    name: clean(e.text()),
                    url: href,
                    host: BASE_URL
                });
            }
        });
        return Response.success(chapters); // Giữ nguyên không Reverse để fix lỗi thứ tự
    }
    return null;
}