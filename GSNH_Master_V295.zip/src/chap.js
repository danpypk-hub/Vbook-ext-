load("config.js");
function execute(url) {
    let res = fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (res.ok) {
        let doc = res.html();
        
        // 1. Phá hủy toàn bộ vùng Header, Footer, Sidebar trước khi vào lấy nội dung
        doc.select("header, nav, footer, .menu, form, input, .search-form, .post-meta, .meta, .chapter-list, .widget").remove();
        
        let content = doc.select("div.content, .entry-content, .reading-content, .main-warp").first();
        
        if(content) {
            content.select("script, style, iframe, a, button, .ads, .text-center, h1, h2, .title, .chapter-title").remove();
            let htmlContent = content.html();

            // Lọc Regex siêu cường cho các đoạn quảng cáo ngoan cố
            htmlContent = htmlContent.replace(/Mời Quý độc giả CLICK[\s\S]*?(?:chân thành cảm ơn!?|Đội ngũ chúng tôi xin chân thành cảm ơn!)/gi, "");
            htmlContent = htmlContent.replace(/Mở ứng dụng shopee[\s\S]*?chương truyện!/gi, "");

            htmlContent = htmlContent.replace(/<\/?(div|p|h\d)[^>]*>/gi, "<br>");
            htmlContent = htmlContent.replace(/(<br\s*\/?>\s*){2,}/gi, '<br>');

            var lines = htmlContent.split(/<br\s*\/?>|\n/i);
            var final = []; 
            var reg = /(“[^”]+”|"[^"]+"|‘[^’]+’|'[^']+')/g;
            
            for (var i = 0; i < lines.length; i++) {
                var l = lines[i].replace(/<[^>]+>/g, '').trim();
                let lowL = l.toLowerCase();
                
                // Diệt ngày tháng lọt nội tuyến
                l = l.replace(/\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}/g, "").trim();
                
                // Diệt các định dạng ID và Tiêu đề lọt vào (#GSNH 1691 - Chương 6)
                if (/^(?:#|ttty|gsnh|ttyy)[\s\-]*\d*[\s\-–]*Chương\s*\d+/i.test(l) || /^Chương\s*\d+$/i.test(l)) {
                    continue;
                }
                
                // TẤM KHIÊN THÉP: Chặn toàn bộ các câu rác ở Top và Bottom theo yêu cầu
                if (!l || l === "–" || l === "-" || l === "Chương" || l === "10" ||
                    lowL.includes("đang tìm") ||
                    lowL.includes("tìm kiếm truyện") ||
                    lowL.includes("cập nhật lúc") ||
                    lowL.includes("lượt xem") ||
                    lowL.includes("mời quý độc giả") ||
                    lowL.includes("liên kết hoặc ảnh") ||
                    lowL.includes("chân thành cảm ơn") ||
                    lowL.includes("đội ngũ chúng tôi") ||
                    lowL.includes("danh sách chương") ||
                    lowL.includes("bạn đang xem chương") ||
                    lowL.includes("truyện hay mỗi ngày") ||
                    lowL.includes("copyright") ||
                    lowL.includes("website đang hoạt động") ||
                    lowL.includes("đọc từ đầu") || 
                    lowL.includes("đọc tập mới") || 
                    lowL.includes("tác giả") || 
                    lowL.includes("trạng thái") ||
                    lowL.includes("thể loại")) {
                    continue;
                }
                
                // In nghiêng hội thoại
                var pts = l.split(reg);
                for (var j = 0; j < pts.length; j++) {
                    var p = pts[j].trim();
                    if (!p) continue;
                    if (/^(“.*”|".*"|‘.*’|'.*')$/.test(p)) final.push("<p><i>" + p + "</i></p>");
                    else final.push("<p>" + p + "</p>");
                }
            }
            return Response.success(final.join(""));
        }
    }
    return null;
}