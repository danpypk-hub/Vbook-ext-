load("config.js");
function execute(url, page) {
    if (!page) page = '1';
    let res = fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (res.ok) {
        let data = [];
        res.html().select("article, .post, .item, .post-item, .type-post").forEach(e => {
            let t = e.select("h2.title a, .post-title a, h3 a, h1 a, h4 a").first();
            if (t) {
                let img = e.select("img").first();
                let cover = img ? (img.attr("data-src") || img.attr("data-lazy-src") || img.attr("src") || "") : "";
                if (cover.startsWith("//")) cover = "https:" + cover;
                data.push({ name: t.text().trim(), link: t.attr("href"), cover: cover, host: BASE_URL });
            }
        });
        return Response.success(data, (parseInt(page) + 1).toString());
    }
    return null;
}