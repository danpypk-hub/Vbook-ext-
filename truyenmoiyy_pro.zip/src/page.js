function execute(url) {
    var res = fetch(url);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    
    var total = 1;
    doc.select(".pagination li a").forEach(function(e) {
        var match = e.attr("href").match(/trang-(\d+)/);
        if (match && parseInt(match[1]) > total) {
            total = parseInt(match[1]);
        }
    });
    
    var list = [];
    var baseUrl = url.replace(/\/trang-\d+$/, "").replace(/\/$/, "");
    
    for (var i = 1; i <= total; i++) {
        list.push(baseUrl + "/trang-" + i);
    }
    
    return Response.success(list);
}