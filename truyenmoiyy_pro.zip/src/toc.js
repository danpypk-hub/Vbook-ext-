function execute(url) {
    var res = fetch(url);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    var chaps = [];
    
    doc.select(".list-chapter li a").forEach(function(e) {
        var link = e.attr("href");
        if (link.indexOf("http") !== 0) link = "https://truyenmoiyy.com" + link;
        
        chaps.push({
            name: e.select(".chapter-text").text().trim(),
            url: link,
            host: "https://truyenmoiyy.com"
        });
    });
    
    return Response.success(chaps);
}