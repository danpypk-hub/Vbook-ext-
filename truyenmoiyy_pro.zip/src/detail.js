function execute(url) {
    var res = fetch(url);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    
    var name = doc.select(".story-title").text().trim() || doc.select("h1").text().trim();
    var cover = doc.select(".book img").first().attr("src") || doc.select("meta[property='og:image']").attr("content");
    if (cover && cover.indexOf("http") !== 0) cover = "https://truyenmoiyy.com" + cover;
    
    var authorEl = doc.select("[itemprop=author] [itemprop=name]").first() || doc.select(".author").first();
    var author = authorEl ? authorEl.text().replace(/Tác giả\s*:/i, "").trim() : "Đang cập nhật";
    
    var genres = [];
    var genreNames = [];
    doc.select(".info a[itemprop=genre], .info a[href*='the-loai']").forEach(function(e) {
        var gName = e.text().trim();
        var gLink = e.attr("href");
        if (gLink.indexOf("http") !== 0) gLink = "https://truyenmoiyy.com" + gLink;
        genres.push({
            title: gName,
            input: gLink,
            script: "gen.js"
        });
        genreNames.push(gName);
    });
    
    // Rút xuất toàn bộ văn bản thuần (text) trên trang web để dò tìm
    var rawText = doc.text();
    var status = rawText.indexOf("Hoàn thành") !== -1 ? "Hoàn thành" : "Đang ra";
    
    // --- THUẬT TOÁN LẤY SỐ CHƯƠNG TRỰC TIẾP TỪ WEB ---
    var chapters = "Đang cập nhật";
    
    // 1. Quét tìm chính xác cụm từ "Số Chương: xxx" trên giao diện
    var chapMatch = rawText.match(/Số [Cc]hương[\s:]*([\d,.]+)/);
    if (chapMatch) {
        chapters = chapMatch[1] + " chương";
    } 
    // 2. Dự phòng 1: Nếu web không ghi tổng số, bắt con số từ tên "Chương mới nhất"
    else {
        var latestChap = doc.select("ul.l-chapters li a, .latest-chapter a").first().text();
        if (latestChap) {
            var m = latestChap.match(/Chương\s*(\d+)/i);
            if (m) chapters = m[1] + " chương";
        }
    }
    // 3. Dự phòng 2: Nếu vẫn không có gì, mới quay lại thuật toán ước tính (trang x 50)
    if (chapters === "Đang cập nhật") {
        var lastPageHref = doc.select(".pagination li a").last();
        if (lastPageHref && lastPageHref.attr("href")) {
            var mp = lastPageHref.attr("href").match(/trang-(\d+)/);
            if (mp) chapters = "~ " + (parseInt(mp[1]) * 50) + " chương";
        }
    }
    
    var detailInfo = [];
    detailInfo.push("👤 Tác giả: " + author);
    detailInfo.push("ℹ️ Tình trạng: " + status);
    detailInfo.push("📊 Số chương: " + chapters);
    detailInfo.push("🏷️ Thể loại: " + (genreNames.length > 0 ? genreNames.join(", ") : "Chưa rõ"));
    
    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: doc.select(".desc-text").html() || "Đang cập nhật mô tả...",
        detail: detailInfo.join("<br>"),
        genres: genres,
        host: "https://truyenmoiyy.com"
    });
}
