function execute() {
    var res = fetch("https://truyenmoiyy.com/");
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    var data = [];
    doc.select(".dropdown-menu.multi-column li a").forEach(function(e) {
        data.push({
            title: e.text().trim(),
            input: e.attr("href"),
            script: "gen.js"
        });
    });
    return Response.success(data);
}