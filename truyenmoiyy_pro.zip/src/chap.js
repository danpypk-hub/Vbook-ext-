function execute(url) {
    var res = fetch(url);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    var content = doc.select("article.chapter-content").first();
    if (!content) return null;
    content.select("script, iframe, .ads").remove();
    return Response.success(content.html());
}