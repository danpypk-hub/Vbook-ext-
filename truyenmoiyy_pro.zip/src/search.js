function execute(key, page) {
    if (!page) page = '1';
    var fetchUrl = "https://truyenmoiyy.com/tim-kiem?tu-khoa=" + key + "&trang=" + page;
    var res = fetch(fetchUrl);
    if (!res.ok) return null;
    var doc = res.html('utf-8');
    var data = [];
    doc.select(".list-truyen .row[itemscope]").forEach(function(e) {
        var a = e.select(".truyen-title a").first();
        var img = e.select("img[itemprop=image]").first();
        var author = e.select(".author").first();
        if (a && img) {
            var link = a.attr("href");
            if (link.indexOf("http") !== 0) link = "https://truyenmoiyy.com" + link;
            data.push({
                name: a.text().trim(),
                link: link,
                cover: img.attr("src"),
                description: author ? author.text().trim() : "",
                host: "https://truyenmoiyy.com"
            });
        }
    });
    var hasNext = doc.select(".pagination li a[rel=next]").length > 0;
    if (hasNext) {
        var next = parseInt(page) + 1;
        return Response.success(data, next.toString());
    }
    return Response.success(data);
}