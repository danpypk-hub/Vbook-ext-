function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let coverImg = doc.select(".wrap-detail img.lazyloaded").first();
        let genres = [];
        doc.select(".info span[itemprop='genre']").forEach(e => genres.push(e.text()));

        return Response.success({
            name: doc.select("h1.title").text(),
            cover: coverImg.attr("data-src") || coverImg.attr("src"),
            author: "@R",
            description: doc.select(".content1").html(),
            detail: "Thể loại: " + genres.join(", "),
            host: "https://metruyenhot.vn"
        });
    }
    return null;
}