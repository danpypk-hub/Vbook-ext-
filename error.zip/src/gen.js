function execute(url, page) {
    if (!page) page = '1';
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let items = doc.select(".section-hot-book .book-item");
        let list = [];
        items.forEach(e => {
            let a = e.select("a.thumb").first();
            let img = a.select("img").first();
            list.push({
                name: e.select(".name-book").text(),
                link: a.attr("href"),
                cover: img.attr("data-src") || img.attr("src"),
                description: e.select(".rate").text(),
                host: "https://metruyenhot.vn"
            });
        });
        return Response.success(list);
    }
    return null;
}