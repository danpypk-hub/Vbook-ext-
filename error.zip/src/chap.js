function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        
        // 1. Loại bỏ các thành phần gây nhiễu trước (Header, Footer, Sidebar, Ads)
        doc.select("script, style, ins, .adsbygoogle, header, footer, .sidebar, .nav").remove();

        // 2. KỸ THUẬT QUÉT VÙNG NỘI DUNG (Heuristic Selection)
        // Thử các selector phổ biến nhất của metruyenhot
        let contentElement = doc.select(".content-story, .story-detail-content, #content-story, .chapter-c").first();

        // 3. FALLBACK: Nếu vẫn không thấy, lấy thẻ div nào chứa nhiều thẻ <p> nhất
        if (!contentElement || contentElement.text().length < 100) {
            let maxLen = 0;
            doc.select("div").forEach(div => {
                let textLen = div.text().length;
                if (textLen > maxLen) {
                    maxLen = textLen;
                    contentElement = div;
                }
            });
        }

        if (contentElement) {
            // Lọc link rác bên trong nội dung
            contentElement.select("a, .ads-container").remove();
            
            let html = contentElement.html();

            // 4. CLEANING & FORMATTING (Theo tiêu chuẩn in ấn)
            let cleaned = html
                .replace(/<br\s*\/?>/gi, "\n")
                .replace(/<\/p>|<div.*?>|<\/div>/gi, "\n\n")
                .replace(/<[^>]*>/g, "") // Xóa sạch HTML
                .replace(/&nbsp;/g, " ")
                .replace(/(metruyenhot|truyenfull|đọc tại|tiên hiệp|ngôn tình)/gi, "") // Dọn rác text ẩn
                .replace(/\n\s*\n/g, "\n\n") // Xóa dòng trống thừa
                .trim();

            // Tạo thụt đầu dòng 4 khoảng trắng cho mỗi đoạn
            let finalContent = cleaned.split('\n').map(line => {
                let t = line.trim();
                return t.length > 0 ? "    " + t : "";
            }).filter(line => line.length > 0).join("\n\n");

            return Response.success(finalContent);
        }
    }
    return null;
}