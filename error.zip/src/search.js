function execute(key, page) {
    if (!page) page = '1';
    let url = "https://metruyenhot.vn/tim-truyen?q=" + encodeURIComponent(key) + "&page=" + page;
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        // Áp dụng bộ chọn tương tự gen.js dựa trên HTML trang tìm kiếm
        let items = doc.select(".book-item"); 
        let list = [];
        items.forEach(e => {
            let a = e.select("a.thumb").first();
            if(a) {
                let img = a.select("img").first();
                list.push({
                    name: e.select(".name-book").text() || a.attr("title"),
                    link: a.attr("href"),
                    cover: img ? (img.attr("data-src") || img.attr("src")) : "",
                    description: e.select(".rate").text() || "",
                    host: "https://metruyenhot.vn"
                });
            }
        });
        return Response.success(list);
    }
    return null;
}