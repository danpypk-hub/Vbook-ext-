function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        let list = [];
        
        // 1. Quét diện rộng trong cột chính
        let allLinks = doc.select(".col-lg-9 a"); 
        
        allLinks.forEach(e => {
            let link = e.attr("href");
            let name = e.text().trim();
            
            // Lọc: Phải có chữ "Chương" và link chứa "chuong-"
            if (link && link.indexOf("chuong-") !== -1 && /^Chương\s+\d+/.test(name)) {
                list.push({
                    name: name,
                    url: link,
                    host: "https://metruyenhot.vn"
                });
            }
        });
        
        // 2. Khử trùng lặp (Clean & Smooth)
        let uniqueList = [];
        let urlSet = new Set();
        list.forEach(item => {
            if (!urlSet.has(item.url)) {
                urlSet.add(item.url);
                uniqueList.push(item);
            }
        });

        // 3. PHÂN TRANG TỐI ƯU (Dựa trên HTML bạn cung cấp)
        // Tìm thẻ li có class 'next' và lấy href của thẻ a bên trong
        let next = doc.select(".pagination li.next a").attr("href");
        
        if (next && next !== "#" && next.trim() !== "") {
            if (!next.startsWith("http")) next = "https://metruyenhot.vn" + next;
            return Response.success(uniqueList, next);
        }

        return Response.success(uniqueList);
    }
    return null;
}