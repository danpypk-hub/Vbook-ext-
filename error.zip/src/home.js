function execute() {
    return Response.success([
        { title: "Truyện Đề Cử", input: "https://metruyenhot.vn", script: "gen.js" }
    ]);
}